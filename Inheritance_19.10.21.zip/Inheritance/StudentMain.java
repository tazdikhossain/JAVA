public class StudentMain
{
	public static void main(String[] args)
	{
		Human h1=new Human("Mr. X",20,5.9F);
		h1.showInfo();
		
		Student s1=new Student("Ms. Y",21,5.4F,3.95F,"11-2");
		s1.showInfo();
	}
}