public class MyNull
{
	void show(int a,int b)
	{
		int result=a/b;
		System.out.println("Result:\t"+result);
	}
	public static void main(String[] args)
	{
		int a=10;
		int b=1;
		MyNull ob=null;
		try
		{
		   ob.show(a,b);
		}
		
		catch(NullPointerException e)
		{   
			e.printStackTrace();
			System.out.println("Object referred to NULL");
		}
				
		catch(Exception e)
		{
			System.out.println("Default Catch Block");
		}
		
	}
}