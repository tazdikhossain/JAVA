public class MyArray
{
	
	public static void main(String[] args)
	{
		int[] a=new int[5];
		
		try
		{
		   System.out.println("Value :\t"+a[4]);
		   //throw new Exception();
		   
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Index out of bound of Array");
		}
				
		catch(Exception e)
		{
			System.out.println("Default Catch Block");
		}
		finally
		{
			System.out.println("End of Program");
		}
		
	}
}