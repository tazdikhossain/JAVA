public class A
{
	public void show()throws ClassNotFoundException
	{   
		Class load=Class.forName("B");
		System.out.println("Found");
	}
	public static void main(String[] arg)throws ClassNotFoundException
	{ 
	try
	{
		Class load=Class.forName("A");
		System.out.println("Found");
		A ob=new A();
		ob.show();
	}
	catch(ClassNotFoundException e)
	{
		System.out.println("Missed");
	}
}
}