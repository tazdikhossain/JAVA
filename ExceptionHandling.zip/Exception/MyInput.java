import java.util.Scanner;
import java.util.InputMismatchException;
public class MyInput
{
	
	public static void main(String[] args)
	{
		int a;
		Scanner sin=new Scanner(System.in);
		try
		{
			System.out.println("Input Value:\t");
			a=sin.nextInt();
		    System.out.println("a is :\t"+a);
		}
		
		catch(InputMismatchException e)
		{
			System.out.println("Input Mismatch");
			System.out.println(e.toString());
			//e.getMessage();
			//e.printStackTrace();
		}
				
		catch(Exception e)
		{
			System.out.println("Default Catch Block");
		}
		finally
		{
			System.out.println("End of Program");
		}
		
		
	}
}