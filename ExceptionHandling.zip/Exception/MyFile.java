import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class MyFile
{
	public static void main(String[] args)throws FileNotFoundException//IOException
	{
		try
		{
	     FileWriter fout=new FileWriter("F.txt",true); 
        int a=100;
        fout.write("Hello JAVA \n");			
        fout.write(new Integer(a).toString()+"\t"+"Hello\n"); 
        		
        fout.close(); 
		
		//fout.write("Last Topic\n");	
		/*BufferedWriter out = new BufferedWriter(fout);
        fout.append("aString1\n");
		out.append("aString2\n");*/
       
		FileReader inFile=new FileReader("F:/AIUB-Rushee_ACER _Laptop/Drive-F/Fall2019/Final Term/Exception/G.txt");
		Scanner sin=new Scanner(inFile);
		String s;//int b=Integer.parseInt(s);
		while(sin.hasNext())
		{
			s=sin.nextLine();
			System.out.println(s);
		}
		inFile.close();
		
			
         
		}
		catch(FileNotFoundException e)
		{
			System.out.println("File not Found Exception");
		}
		
		catch(IOException e)
		{
			System.out.println("IOException");
		}
		
		
		
		
		
		finally
		{
			//fout.close(); 
		}
		
	}
}