public class Start
{
	public static void main(String[] args)
	{
		//A ob=new A();
		//ob.show();
		B ob=new B(50);
		ob.show();
	}
}