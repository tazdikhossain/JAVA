public final class A
{
	//public final int x=20;
	public A()
	{
		//this.x=10;
		//System.out.println("Value of x: "+this.x);
	}
	public final void show()
	{
		//x=20;
		//System.out.println("Value of x: "+x);
	}
}
