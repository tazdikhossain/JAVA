public class studentMain
{
	public static void main(String[] args)
	{
		Student s1=new Student();
		/*s1.id="18-2424-2";
		s1.name="Mr. X";
		s1.cgpa=3.96;*/
		//s1.setValues("111-2","Ms. Y",3.98);
		s1.setId("12-2");
		s1.setName("ABC");
		s1.setCgpa(3.75);
		//s1.show();
		System.out.println("ID:"+s1.getId());
		System.out.println("Name:"+s1.getName());
		System.out.println("CGPA:"+s1.getCgpa());
		
	}
}