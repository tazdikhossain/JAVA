public class A
{
	protected int a;
	
	public A()
	{
		System.out.println("Default of A");
	}
	
	public void setValues(int a)
	{
		this.a=a;
	}
	public void show()
	{
		System.out.println("Value of a: "+this.a);
	}
}