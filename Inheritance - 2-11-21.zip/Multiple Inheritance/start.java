public class start
{
	public static void main(String[] args)
	{
		C ob1=new C();
		ob1.setValues(10,20,30);
		ob1.show();
	}
}