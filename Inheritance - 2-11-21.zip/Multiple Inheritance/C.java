public class C extends B
{
	int c;
	public C()
	{
		System.out.println("Default of C");
	}
	
	public void setValues(int a,int b,int c)
	{   
	    super.setValues(a,b);
		this.c=c;
	}
	public void show()
	{
		System.out.println("Value of a,b,c :"+this.a+"\t"+this.b+"\t"+this.c);
	}
}