public class B extends A
{
	protected int b;
	
	public B()
	{
		System.out.println("Default of B");
	}
	
	public void setValues(int a,int b)
	{   
	    super.setValues(a);
		this.b=b;
	}
	public void show()
	{
		System.out.println("Value of a,b :"+this.a+"\t"+this.b);
	}
}