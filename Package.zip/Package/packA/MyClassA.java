package packA;

public class MyClassA
{
    int a;//default
	public MyClassA()
	{
		System.out.println("Default in packA");
		//this.a=a;
	}
	public void show()
	{
		System.out.println("Value of a :\t"+a);
	}
}