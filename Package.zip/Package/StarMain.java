import packA.MyClassA;
import packB.*;


public class StarMain extends packB.MyClassA
{
	public static void main(String[] args)
	{ 
	   //packA.MyClassA ob1=new packA.MyClassA();
	  //ob1.a=10;
	  //packB.MyClassA ob1=new packB.MyClassA();
	  StarMain sm=new StarMain();
	  sm.a=10;
	  sm.show();
	}
}