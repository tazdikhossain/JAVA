public class start
{
	public static void main(String[] args)
	{
		
		Passport p=new Passport("124-2123");
		//p1.show();
		Person ob=new Person("X","Bashundhara",70,p);
		ob.show();
	
	}
}