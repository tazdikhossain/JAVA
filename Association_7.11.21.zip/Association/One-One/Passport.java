public class Passport
{
	private String pid;
	
	public Passport(String pid)
	{
		this.pid=pid;
	}
	public void show()
	{
		System.out.println("Passport Info.............");
		System.out.println("Passport no :"+this.pid);
	}
}