public class Person
{
	private String name;
	private String address;
	private int age;
	private Passport p1;
	
	public Person(String name,String address,int age,Passport p1)
	{
		this.name=name;
		this.address=address;
		this.age=age;
		this.p1=p1;
	}
	public void show()
	{
		System.out.println("Person Info................");
		System.out.println("Name :"+this.name);
		System.out.println("Address :"+this.address);
		System.out.println("Age :"+this.age);
		//System.out.println("Passport :"+this.p1.pid);
		p1.show();
	}
	
}