public class Bank
{
	private int bankId;
	private String bankName;
	private Account[] acc;
	private int counter;
	
	public Bank(int bankId,String bankName)
	{
		this.bankId=bankId;
		this.bankName=bankName;
		acc=new Account[100];
	}
	public void addAccount(Account acc)
	{
		if(counter<this.acc.length)
		{
			this.acc[counter]=acc;
			counter++;
		}
		
	}
	public void show()
	{
		System.out.println("Bank Info.........");
		System.out.println("ID :"+this.bankId);
		System.out.println("Bank Name :"+this.bankName);
		for(int i=0;i<counter;i++)
		{
			this.acc[i].show();
		}
	
		
	}

}
