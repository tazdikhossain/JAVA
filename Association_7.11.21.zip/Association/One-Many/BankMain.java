public class BankMain
{
	public static void main(String[] args)
	{
		Bank b1=new Bank(1,"DBBL");
		//b1.show();
		Account a1=new Account("11A","Mr. X",293);
		b1.addAccount(a1);
		Account a2=new Account("12A","Ms. ABC",239493);
		b1.addAccount(a2);
		Account a3=new Account("13A","Mr. XYZ",2593);
		b1.addAccount(a3);
		Account a4=new Account("14A","bhjhjhBC",2393);
		b1.addAccount(a4);
		Account a5=new Account("15A","AhjhjBC",509493);
		b1.addAccount(a5);
		//a1.show();
		b1.show();
		
	}
}