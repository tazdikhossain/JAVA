import java.util.Scanner;

public class A
{
	public static void main(String[] args)
	{
		int a[]=new int[5];//1D Array
	    //int a[]={1,2,3,4};
		
		//a[0]=1;
		//System.out.println("Array :"+a[0]);
		Scanner sin=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			 //a[i]=10;
			System.out.println("Input value for Array["+i+"] : ");
			a[i]=sin.nextInt();
			//System.out.println("Array ["+i+"]:"+a[i]);
		}
		for(int i=0;i<a.length;i++)
		{
			
			System.out.println("Array ["+i+"]:"+a[i]);
		}
		
		
	}
}