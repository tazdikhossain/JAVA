import java.util.Scanner;

public class B
{
	public static void main(String[] args)
	{
		int a[][]=new int[5][4];//2D Array
		//int a[][]=new int[][]{{1,2,3},{1,2,5}};
		//int a[][]={{1,2,3},{1,2,5}};
		//int a[][];
		//a=new int[5][4];
		/*a[0][0]=10;
		a[4][3]=500;*/
		Scanner sin=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<4;j++)
			{
			 
			System.out.println("Input value for Array["+i+","+j+"] : ");
			a[i][j]=sin.nextInt();
			//System.out.println("Array ["+i+","+j+"]:"+a[i][j]);
			}
		}
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
			System.out.println("Array ["+i+","+j+"]:"+a[i][j]);
			}
		}
		
		
	}
}