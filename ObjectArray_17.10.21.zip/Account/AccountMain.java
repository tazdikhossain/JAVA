import java.util.Scanner;
public class AccountMain
{
	public static void main(String[] args)
	{
		/*Account ob1=new Account();
		ob1.setValues("11-2","Mr. X",20000);
		ob1.show();
		Account ob2=new Account("122-A","Ms Y",5000);
		ob2.show();
		ob1.transfer(ob2,1000);
		
		ob1.show();
		ob2.show();*/
		//Account ob[]=new Account[]{ob1,ob2};
		//Account ob[];
		//ob=new Account[5];
		Scanner sin=new Scanner(System.in);
		Account ob[]=new Account[3];
		
		for(int i=0;i<ob.length;i++)
		{
			
			System.out.println("Input ID :");
			String id=sin.next();
			System.out.println("Input Name :");
			String name=sin.next();
			System.out.println("Input Balance :");
			double balance=sin.nextDouble();
			ob[i]=new Account(id,name,balance);
			//flush();
			
		
		}
		for(int i=0;i<ob.length;i++)
		{
			ob[i].show();
		}
		
		
		
		
	}
}