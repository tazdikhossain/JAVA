public class HMain
{
	public static void main(String[] args)
	{
		Human h1=new Baby("RR",2,"22-a");
		h1.show();
		
		h1=new Customer("Mr. X",30,"45pp");
		h1.show();
	}
}