public class Baby extends Human
{
	
	public String birthId;
	
	
	public Baby()
	{
		System.out.println("Default in Baby");
	}
	public Baby(String name,int age,String birthId)
	{
		super(name,age);
		System.out.println("Valued in Baby");
		this.birthId=birthId;
	}
	
	public void show()
	{
		super.show();
		System.out.println("Baby Info.........");
		System.out.println("Birth Id :"+this.birthId);
	}
	public void print()
	{
		System.out.println("Hello");
	}
}