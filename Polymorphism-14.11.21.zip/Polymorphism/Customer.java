public class Customer extends Human
{
	public String custId;
	
	
	public Customer()
	{
		System.out.println("Default in Customer");
	}
	
	public Customer(String name,int age,String custId)
	{
		super(name,age);
		System.out.println("Valued in Customer");
		this.custId=custId;
	}
	
	public void show()
	{
		super.show();
		System.out.println("Customer Info.........");
		System.out.println("Customer Id :"+this.custId);
	}
}
	