public class Human
{
	public String name;
	public int age;
	
	
	public Human()
	{
		System.out.println("Default in Human");
	}
	public Human(String name,int age)
	{
		System.out.println("Valued in Human");
		this.name=name;
		this.age=age;
	}
	
	public void show()
	{
		System.out.println("Human Info.........");
		System.out.println("Name :"+this.name);
		System.out.println("Age :"+this.age);
	}
	public void print()
	{
	}
	
}