public class Start
{
	public static void main(String[] args)
	{
		System.out.println("Value args[0] :"+args[0]);
		System.out.println("Value args[1] :"+args[1]);

	}
}